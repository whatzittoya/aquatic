 <link href="{{ mix('css/app.css') }}" type="text/css" rel="stylesheet" />
<script src="{{ mix('js/app.js') }}" type="text/javascript" defer></script>