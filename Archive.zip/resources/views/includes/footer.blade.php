<footer class="footer">
    <div class="container" style="padding:0%;">
        <span class="text-muted">Copyright 2020 Riau Aquatic</span>
    </div>
</footer>