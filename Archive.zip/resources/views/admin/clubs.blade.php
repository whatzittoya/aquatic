@extends('adminlte::page')
@include('includes.vue')


@section('content_header')
    <h1 class="m-0 text-dark">Members</h1>
@stop

@section('content')
 <div id="app">
 </div>
@stop

