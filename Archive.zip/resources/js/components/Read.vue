<template>
  <div>
        <!-- <modal v-if="showModal" @close="showModal = false" v-bind:test='form'> -->
  <modal v-if="showModal" @close="showModal = false"  :edit="edit" :id="id" >
   
  </modal>

    <div class="row">

      <div class="col-md-12">
         <div class="col-md-4">
            <!-- push router ke form membuat data -->
             <button id="show-modal" @click="createData()" class="btn btn-primary">Tambah Member</button>
            <!-- <router-link class="btn btn-primary w-100" to="/admin/member/new">+ Tambah</router-link> -->
          </div>   
     <v-data-table
    :headers="headers"
    :items="members"
   
    class="elevation-1"
  >
<template v-slot:item.best_time="{ item }">
      {{ timeFormat(item.best_time) }}
    </template>
    <template v-slot:item.action="{ item }">
      <v-icon
        small
        class="mr-2"
        @click="editData(item.id)"
      >
        edit
      </v-icon>
      <v-icon
        small
        @click="deleteData(item.id)"
      >
        delete
      </v-icon>
     
      <a :href="'/admin/members/'+item.id"  target="_blank">
       <v-icon small>
        insert_drive_file
      </v-icon></a>
      <!-- <a :href="'/admin/members/'+member.id" target="_blank" class="btn btn-primary">Lampiran</a> -->
    </template>
  </v-data-table>
        <div class="row">
     
         
        </div>
        <br>
        
      </div>
    </div>
  </div>
</template>

<!-- script js -->
<script>
import modal from "./ModalMember.vue";

export default {
  components: {
    modal
  },
  computed: {
    COMPUTED_PROPERTY: function() {
      return 1 + 1;
    }
  },
  data() {
    return {
      // variable array yang akan menampung hasil fetch dari api

      headers: [
        { text: "Nama", value: "name" },
        { text: "Tanggal Lahir", value: "born_date" },
        { text: "Waktu Tercepat", value: "best_time" },
        { text: "Klub", value: "clubs.name" },
        { text: "Aksi", value: "action", sortable: false }
      ],

      members: [],
      edit: false,
      id: 0,
      showModal: false,
      form: {
        name: "form-fromparent"
      }
    };
  },
  created() {
    this.loadData();
  },
  methods: {
    loadData() {
      // fetch data dari api menggunakan axios
      axios.get("/api/members").then(response => {
        // mengirim data hasil fetch ke varibale array persons
        this.members = response.data;
        // console.log(response.data);
      });
    },
    deleteData(id) {
      // delete data
      if (confirm("Apakah anda yakin ingin menghapus data ini?")) {
        axios.delete("/api/members/" + id).then(response => {
          this.loadData();
        });
      }
    },
    editData(id) {
      // delete data
      this.edit = true;
      this.id = id;
      this.showModal = true;
    },
    createData() {
      // delete data
      this.edit = false;
      this.id = 0;
      this.showModal = true;
    },
    timeFormat(milisecond) {
      let hour = 0;
      let minute = 0;
      let second = 0;
      let mili = 0;

      hour = Math.floor(milisecond / 3600000);

      if (hour.toString.length < 2) {
        hour = ("0" + hour).slice(-2);
      }
      milisecond = milisecond - hour * 3600000;

      minute = Math.floor(milisecond / 60000);
      minute = ("0" + minute).slice(-2);
      milisecond = milisecond - minute * 60000;
      second = Math.floor(milisecond / 1000);
      second = ("0" + second).slice(-2);
      milisecond = milisecond - second * 1000;
      mili = milisecond;
      mili = ("00" + mili).slice(-3);

      return hour + ":" + minute + ":" + second + "." + mili;
    }
  }
};
</script>