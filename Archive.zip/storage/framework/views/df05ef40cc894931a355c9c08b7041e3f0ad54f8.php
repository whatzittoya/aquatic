<html>

<head>
    <link href="<?php echo e(mix('css/app.css')); ?>" type="text/css" rel="stylesheet" />
    <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript" defer></script>
</head>

<body style='background-color: white'>
   <?php echo e($nama); ?>

    <div id="app">
    </div>
</body>

</html><?php /**PATH /Users/sein/Code/project/aquatic/resources/views/test.blade.php ENDPATH**/ ?>