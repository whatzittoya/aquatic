<!doctype html>
<html>
<head>
   <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <style>
html, body {
  height: 100%;
}
body {
  display: flex;
  flex-direction: column;
  background-color:#c1e1ec !important
}
.content {
  flex: 1 0 auto;
  background-color:#f8fafc
}
.footer {
  flex-shrink: 0;
  background-color: #fdd835;
   width: 100%;
    height: 60px;
    line-height: 60px;
}
      </style>
</head>
<body >

<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main role="main" class="container content">
   <div class=" justify-content-center" >
   
           <?php echo $__env->yieldContent('content'); ?>
 </div>

</main>  
       <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('js'); ?>

</body>
</html><?php /**PATH /Users/sein/Code/project/aquatic/resources/views/layouts/default.blade.php ENDPATH**/ ?>