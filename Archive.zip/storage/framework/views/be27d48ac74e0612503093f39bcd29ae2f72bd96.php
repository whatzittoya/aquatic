<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Events</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <p class="mb-0"><?php echo json_encode($events, 15, 512) ?>;</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sein/Code/project/aquatic/resources/views/admin/event.blade.php ENDPATH**/ ?>