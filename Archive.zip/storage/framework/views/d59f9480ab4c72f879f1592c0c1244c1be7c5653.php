<?php echo $__env->make('includes.vue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Members</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <div id="app">
 </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sein/Code/project/aquatic/resources/views/admin/members.blade.php ENDPATH**/ ?>