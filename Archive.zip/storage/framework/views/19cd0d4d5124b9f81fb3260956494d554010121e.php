<?php $__env->startSection('content'); ?>
<div class="container">
    <div class=" mt-2">
    <h2>Form Pendaftaran</h2>
    </div>
    <hr>

<ul>
<?php if($errors->any()): ?>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><label class="text-danger"><?php echo e($error); ?></label></li>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php endif; ?>
 <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
</ul>

<form action="<?php echo e(route('register')); ?>" method="POST" enctype="multipart/form-data">
   <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>

  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Klub</label>
    <div class="col-sm-10">
      <select class="custom-select" name="klub" >

           <?php $__currentLoopData = $club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($item->id); ?>" <?php echo e(old('klub' ) == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
    </select>

    </div>
  </div>
  <div class="form-group row">
    <label for="Nama" class="col-sm-2 col-form-label" >Nama Member</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="nama" id="t_nama" value="<?php echo e(old('nama')); ?>" required> 
    </div>
  </div>
  <div class="form-group row">
    <label for="Nama" class="col-sm-2 col-form-label" >Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
    </div>
  </div>
  <div class="form-group row">
    <label for="Tanggal" class="col-sm-2 col-form-label">Tanggal Lahir</label>
    <div class="col-sm-10">
      <input type="date" class="form-control" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" required>
    </div>
  </div>
    
    <div class="form-group row">
    <label for="Dokumen" class="col-sm-2 col-form-label">Dokumen</label>
   
    <div class="col-sm-10">
      <div class="input-group mb-3">
        
  <div class="custom-file">
    <input type="file" class="custom-file-input" name="dokumen" accept=".jpeg,.jpg,.png,application/pdf,.pdf"  id="f_upload" required>
    <label class="custom-file-label" for="inputGroupFile02" aria-describedby="inputGroupFileAddon02">Choose file</label>
  </div>
  
</div>
<label for="upload" id="upload_info" class="text-muted">(extension:jpg,jpeg,png,pdf max-size:500KB)</label>
<label for="upload" id="upload_msg" class="text-danger"></label>
    </div>
  </div>
  <button class="btn btn-primary btn-md active" role="button" aria-pressed="true" type="submit">Simpan</button>
<a href="<?php echo e(route('register')); ?>" class="btn btn-secondary btn-md active" role="button" aria-pressed="true">Batal</a>
</form>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="<?php echo e(URL::asset('vendor/adminlte/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.mask.min.js')); ?>"></script>
    <script>
      $(document).ready(function() {
   $('#waktu').mask('00:00:000', {placeholder: "00:00:000"});
   bsCustomFileInput.init();

$('#f_upload').bind('change', function() {

  var msg=this.files[0].size > 1000000 ? "The file size is too big":""
  
$("#upload_msg").text(msg);
});
      
});

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sein/Code/project/aquatic/resources/views/auth/register.blade.php ENDPATH**/ ?>