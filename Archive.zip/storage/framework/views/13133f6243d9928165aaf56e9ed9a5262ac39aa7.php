<footer class="footer">
    <div class="container" style="padding:0%;">
        <span class="text-muted">Copyright 2020 Riau Aquatic</span>
    </div>
</footer><?php /**PATH /Users/sein/Code/project/aquatic/resources/views/includes/footer.blade.php ENDPATH**/ ?>