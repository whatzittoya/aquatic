<?php

namespace App\Http\Controllers\API;

use App\Member;
use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserValidated;
use Hash;

class MemberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $member = Member::select('id', 'name', 'born_date', 'best_time', 'club_id', 'filename', 'valid', 'user_id')->with('clubs:id,name')->with('users:id,email')->get();

        return response()->json($member);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //$mimetypes = new \GuzzleHttp\Mimetypes;

        // store
        $user = new User;
        $user->email = $request->email;
        $user->name = $request->name;
        $user->save();

        $member = new Member;
        $member->name       = $request->name;
        $member->club_id       = $request->club_id;
        $member->born_date       = $request->born_date;
        $member->best_time       = $request->best_time;
        $member->valid       = $request->valid;
        $member->user_id       = $user->id;
        $member->save();

        if ($request->valid && is_null($user->username)) {
            $pass = mt_rand(100000, 999999);
            $user->username = $user->email;
            $user->password = Hash::make($pass);
            $user->update();

            $objUser = new \stdClass();
            $objUser->username = $user->username;
            $objUser->password = $pass;
            Mail::to("whosendall@gmail.com")->send(new UserValidated($objUser));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $member = Member::where('id', $id)->select('id', 'name', 'born_date', 'best_time', 'club_id', 'filename', 'valid', 'user_id')->with('clubs:id,name')->with('users:id,email')->first();

        return response()->json($member);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        // store
        // $member = Member::find($id);
        // $member->name       = $request->name;
        // $member->club_id       = $request->club_id;
        // $member->born_date       = $request->born_date;
        // $member->best_time       = $request->best_time;

        // $member->valid       = $request->valid;

        // $member->update();
    }

    public function updateApi(Request $request, $id)
    {

        // store
        $member = Member::find($id);
        $member->name       = $request->name;
        $member->club_id       = $request->club_id;
        $member->born_date       = $request->born_date;
        $member->best_time       = $request->best_time;
        $valid_before = $member->valid;
        $valid_after = $request->valid;
        $member->valid       = $request->valid;
        $member->update();
        $user = User::find($member->user_id);
        if ($valid_before < $valid_after && is_null($user->username)) {
            $pass = mt_rand(100000, 999999);
            $user->username = $user->email;
            $user->password = Hash::make($pass);
            $user->update();

            $objUser = new \stdClass();
            $objUser->username = $user->username;
            $objUser->password = $pass;
            Mail::to("whosendall@gmail.com")->send(new UserValidated($objUser));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Member  $event
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $member = Member::find($id);
        $member->delete();
        return 204;
    }
}
